# Model 
Thio_Class_Training.sav is the trained model
Thio_Class_Sclaed_training.sav is the feature scaler


