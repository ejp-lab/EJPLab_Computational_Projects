# Datasets

Machine lerning in this project was done using a small dataset. To ensure that predictions are not purely a function of hyperparameter tuning, all validation was performed on holdout sets. Hyperparameter tuning was performned using five-fold crossvalidation on all of the data except the hold-out sets. Files include the entire dataset, the CtsL and Kallirkein training set, and the CtsL and Kallikrein hold-out set. If you are interested in any other hold-out set, just delete it from the entire dataset file.
