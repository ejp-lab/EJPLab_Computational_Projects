# README
These are the required files for running Thio_Class. Sample_Data.csv shows the form that this file must be for the executable to work. Chymotrypsin_uKAAFAAAu.pdb is a smaple input for you to use as practice.
